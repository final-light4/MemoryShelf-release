﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerInteraction : MonoBehaviour
{
    [Header("Interaction Settings")]
    public float interactDistance = 3f;   // 射线检测距离
    public LayerMask interactLayerMask;   // 可交互层（可以为空）

    [Header("UI References")]
    public GameObject interactionPanel;   // UI面板
    public TMP_Text itemNameText;
    public TMP_Text itemDescriptionText;
    public TMP_Text itemPriceText;

    private Camera cam;
    private PickableItem currentItem;
    private PickableItem heldItem;

    private void Start()
    {
        cam = Camera.main;
        if (interactionPanel != null)
            interactionPanel.SetActive(false);
    }

    private void Update()
    {
        HandleRaycast();
        HandleInput();
    }

    private void HandleRaycast()
    {
        Ray ray = new Ray(cam.transform.position, cam.transform.forward);
        RaycastHit hit;

        // 带层过滤的射线检测
        if (Physics.Raycast(ray, out hit, interactDistance, interactLayerMask == 0 ? ~0 : interactLayerMask))
        {
            var pickable = hit.collider.GetComponent<PickableItem>();

            if (pickable != null && pickable.CompareTag("Pickable"))
            {
                if (currentItem != pickable)
                {
                    currentItem = pickable;
                    ShowUI(pickable);
                }

                Debug.DrawRay(ray.origin, ray.direction * interactDistance, Color.red);
                if (hit.collider != null)
                    Debug.DrawLine(ray.origin, hit.point, Color.green);

                return;
            }
        }

        // 未检测到可交互对象
        currentItem = null;
        HideUI();
    }

    private void HandleInput()
    {
        if (currentItem != null && Input.GetKeyDown(KeyCode.E))
        {
            if (heldItem == null)
            {
                // 拿取
                heldItem = currentItem;
                heldItem.gameObject.SetActive(false); // 隐藏物体
                Debug.Log($"✅ 拿取：{heldItem.name}");
            }
        }
        else if (heldItem != null && Input.GetKeyDown(KeyCode.G))
        {
            // 放置
            heldItem.gameObject.SetActive(true);
            heldItem.transform.position = cam.transform.position + cam.transform.forward * 1f;
            heldItem.transform.rotation = Quaternion.identity;
            Debug.Log($"🔄 放置：{heldItem.name}");
            heldItem = null;
        }
    }

    private void ShowUI(PickableItem item)
    {
        if (interactionPanel == null) return;
        interactionPanel.SetActive(true);
        itemNameText.text = item.itemName;
        itemDescriptionText.text = item.itemDescription;
        itemPriceText.text = "$" + item.itemPrice.ToString("F2");
    }

    private void HideUI()
    {
        if (interactionPanel == null) return;
        interactionPanel.SetActive(false);
    }
}
