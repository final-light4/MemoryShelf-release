﻿using UnityEngine;
using UnityEngine.UI;

public class InteractionUI : MonoBehaviour
{
    public Text promptText;
    public Text itemInfoText;

    void Start()
    {
        HidePrompt();
        HideItemInfo();
    }

    public void ShowPrompt(string msg)
    {
        if (promptText)
        {
            promptText.gameObject.SetActive(true);
            promptText.text = msg;
        }
    }

    public void HidePrompt()
    {
        if (promptText) promptText.gameObject.SetActive(false);
    }

    public void ShowItemInfo(string name, float price, string desc)
    {
        if (itemInfoText)
        {
            itemInfoText.gameObject.SetActive(true);
            itemInfoText.text = $"{name}\n价格: ¥{price:F2}\n{desc}";
        }
    }

    public void HideItemInfo()
    {
        if (itemInfoText) itemInfoText.gameObject.SetActive(false);
    }
}
