using UnityEngine;

public class PickableItem : MonoBehaviour
{
    [Header("Item Info")]
    public string itemName = "Unknown Item";
    public float itemPrice = 0f;
    [TextArea]
    public string itemDescription = "No description";

    [HideInInspector] public Vector3 originalPosition;
    [HideInInspector] public Quaternion originalRotation;

    void Start()
    {
        originalPosition = transform.position;
        originalRotation = transform.rotation;
    }
}
